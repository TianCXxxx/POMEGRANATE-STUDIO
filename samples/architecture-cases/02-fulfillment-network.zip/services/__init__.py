"""Illustrative architecture input."""
