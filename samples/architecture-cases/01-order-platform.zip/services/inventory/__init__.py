"""Inventory service."""
